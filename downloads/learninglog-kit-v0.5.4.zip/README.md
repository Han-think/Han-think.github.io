# learninglog-kit 0.5.4

LearningLog is a personal learning pipeline that turns raw study material into reviewed notes and publishable blog drafts.

This kit contains two ways to use LearningLog:

- **Python package / web UI**: the original cross-platform kit under `src/learninglog`.
- **Windows local PowerShell runner**: the mature local workflow under `local_powershell/`.

Version 0.5.4 keeps the Python package intact and updates the Windows runner with a cleaner menu split for daily learning, project series, and personal daily logs.

---

## Which Version Should I Use?

Use the **Python package / web UI** if you want the lighter packaged tool:

```powershell
pip install "learninglog-kit[web,gemini]"
learninglog ui
```

Use the **Windows local PowerShell runner** if you want the full local workflow with local Ollama support, preview, approval, publish, unpublish, daily learning posts, and project series posts:

```powershell
cd local_powershell
.\LearningLog.bat
```

For the Windows runner, read `local_powershell/README.md` first. That document describes the current folder structure, menu flow, and publish safety checks.

---

## Windows Local Runner

The Windows runner is designed around this workspace shape:

```text
00_inbox
01_registry
02_extracted
03_working_notes
04_blog_drafts
05_ready_to_publish
06_published
07_archive
08_templates
09_reports
_local_core
```

The main learning flow is:

```text
intake -> prep -> extract -> blogdraft -> approve -> preview -> publish
```

The launcher now separates three common jobs:

- `LearningLog`: daily study material, AM/PM learning posts, and learning publish flow.
- `Projects`: multi-part project drafts under `04_blog_drafts/projects`.
- `Daily`: separate personal daily reflection logs.

### New in 0.5.4

- Adds a `Projects / Series` launcher menu.
- Adds `run_learninglog_project_series.ps1` for multi-part project drafts.
- Adds a project post template at `08_templates/project_series_post_template.md`.
- Adds section filters to register, preview, approve, and publish scripts.
- Keeps `LearningLog` blog operations scoped to `learning`.
- Keeps `Projects` operations scoped to `projects`.
- Includes a Kaggle House Prices project-series preset for portfolio-style project writeups.
- Preserves the 0.5.3 preview fix for one visible draft.
- Keeps publish safety checks: new/update counts, update confirmation, QA gate, public-policy gate.

---

## Python Package Quick Start

Install:

```bash
pip install learninglog-kit
```

Optional providers:

```bash
pip install "learninglog-kit[gemini]"
pip install "learninglog-kit[groq]"
pip install "learninglog-kit[all]"
```

Initialize a workspace:

```bash
mkdir my-learning
cd my-learning
learninglog init
```

Run the web UI:

```bash
pip install "learninglog-kit[web,gemini]"
learninglog ui
```

The original Python-oriented docs remain in `docs/`, especially:

- `docs/quickstart.md`
- `docs/llm-providers.md`
- `docs/gemini-api-setup.md`
- `docs/daily-workflow.md`

---

## Distribution Notes

This zip intentionally does **not** include private workspace data:

- no `00_inbox/` source files
- no registry rows from a personal workspace
- no extracted notes, working notes, drafts, ready-to-publish posts, published copies, reports, or trash
- no `AGENTS.md` or `_CONTROL/` internal operating documents
- no `.learninglog/config.yaml` secrets

The included files are a clean kit baseline plus the reusable local runner scripts and templates.
