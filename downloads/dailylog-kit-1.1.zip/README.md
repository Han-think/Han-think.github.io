# DailyLog Kit 1.1

> 하루 메모를 카테고리별 **포인트**로 정리해주는 텍스트 브이로그 양식 채우기 키트.
> Turn a quick brain-dump into a tidy daily log, organized by category.

DailyLog Kit is intentionally separate from LearningLog publishing. It creates a local Markdown daily note only. It does not register drafts, publish blog posts, run Hugo, or push to Git.

## 빠른 시작 (Quick Start)

1. **`DailyLog.bat`** 더블클릭 또는 `pwsh -File dailylog.ps1`
2. 오늘 기록할 **요소(카테고리)** 번호 입력, 예: `1,3,8`
3. 오늘 있었던 일을 자유롭게 적기
4. 빈 줄 입력으로 종료
5. `output\YYYY-MM-DD-daily.md` 생성

## LearningLog와의 차이

| 도구 | 용도 | 결과 |
|------|------|------|
| DailyLog Kit | 개인 하루 회고, 일상 메모 정리 | 로컬 `output/*.md` |
| LearningLog `LearningLog` 메뉴 | 수업/학습 노트 처리와 learning 발행 | `04_blog_drafts/learning` |
| LearningLog `Projects` 메뉴 | 프로젝트 회고/분석을 여러 편으로 정리 | `04_blog_drafts/projects` |

DailyLog Kit은 블로그 발행 안전장치가 필요한 글을 다루지 않는다. 블로그에 올릴 학습 글이나 프로젝트 시리즈는 LearningLog Kit의 Windows runner를 사용한다.

## 두 가지 모드

| 모드 | 조건 | 동작 |
|------|------|------|
| 자동 정리 | Ollama 실행 중 | 메모를 카테고리별 포인트로 정리하고 한 줄 회고 생성 |
| 양식 채우기 | LLM 없음 | 빈 양식 생성 후 직접 작성 |

LLM이 없어도 바로 쓸 수 있다. 자동 정리는 편의 기능일 뿐이다.

## 결과 예시

```markdown
---
title: "2026-06-09 데일리 로그"
date: 2026-06-09
categories: ["daily"]
tags: ["학습", "요리", "일상"]
---

## 오늘의 포인트
- 학습: SQLite SELECT, DML 실습
- 요리:
  - 김치찌개 끓임
  - 돼지고기 먼저 볶아 맛이 좋음
- 일상: 산책하며 컨디션 좋음

## 한 줄 회고
SQLite 실습과 맛있는 김치찌개, 산책으로 보낸 나름 괜찮은 하루였다.
```

## 카테고리 바꾸기

`dailylog.ps1` 상단의 `$CATS` 목록만 수정하면 된다.

```powershell
$CATS = @(
    @{ emoji = "📚"; name = "학습" },
    @{ emoji = "☕"; name = "카페" }
)
```

## 옵션 (Options)

```powershell
dailylog.ps1 -Date 2026-06-08
dailylog.ps1 -Model gemma3:27b
dailylog.ps1 -OutDir D:\logs
dailylog.ps1 -NoLLM
dailylog.ps1 -NoOpen
```

## 요구 사항 (Requirements)

- PowerShell 7+ (`pwsh`)
- 선택: Ollama + 모델 1개

## 업로드는 없습니다

이 키트는 로컬에 `.md` 파일을 만들어 줄 뿐, 어디에도 자동 발행/업로드하지 않는다. 정리된 글을 블로그에 올릴지 말지는 사용자가 직접 결정한다.
