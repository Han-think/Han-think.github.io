# DailyLog Kit

> 하루 메모를 카테고리별 **포인트**로 정리해주는 텍스트 브이로그 양식 채우기 키트.
> Turn a quick brain-dump into a tidy daily log (text vlog), organized by category.

## 빠른 시작 (Quick Start)

1. **`DailyLog.bat`** 더블클릭 (또는 `pwsh -File dailylog.ps1`)
2. 오늘 기록할 **요소(카테고리)** 번호 입력 — 예: `1,3,8`
3. 오늘 있었던 일을 **자유롭게** 적기 (여러 줄, 빈 줄 입력하면 끝)
4. → `output\YYYY-MM-DD-daily.md` 로 저장됨. 끝!

## 두 가지 모드

| 모드 | 조건 | 동작 |
|------|------|------|
| **자동 정리** | Ollama 실행 중 | 메모를 던지면 LLM이 카테고리별 포인트로 정리 + 한 줄 회고 |
| **양식 채우기** | LLM 없음 | 빈 양식만 생성 → 직접 채우기 (구조화된 일기장) |

LLM이 없어도 **바로 쓸 수 있습니다.** 자동 정리는 편의 기능일 뿐입니다.

## 결과 예시

```markdown
---
title: "2026-06-09 데일리 로그"
date: 2026-06-09
categories: ["daily"]
tags: ["학습", "요리", "일상"]
---
## 오늘의 포인트
- 📚 학습: SQLite SELECT, DML 실습
- 🍳 요리:
  - 김치찌개 끓임
  - 돼지고기 먼저 볶아 맛이 좋음
- 🌿 일상: 산책하며 컨디션 좋음

## 한 줄 회고
SQLite 실습과 맛있는 김치찌개, 산책으로 보낸 나름 괜찮은 하루였다.
```

## 카테고리 바꾸기

`dailylog.ps1` 상단의 `$CATS` 목록만 수정하면 됩니다 (이모지 + 이름):
```powershell
$CATS = @(
    @{ emoji = "📚"; name = "학습" },
    @{ emoji = "☕"; name = "카페" },   # 추가 예시
    ...
)
```

## 옵션 (Options)

```powershell
dailylog.ps1 -Date 2026-06-08       # 특정 날짜
dailylog.ps1 -Model gemma3:27b      # 다른 Ollama 모델
dailylog.ps1 -OutDir D:\logs        # 저장 위치 변경
dailylog.ps1 -NoLLM                 # LLM 끄고 빈 양식만
dailylog.ps1 -NoOpen                # 저장 후 자동 열기 안 함
```

## 요구 사항 (Requirements)

- **PowerShell 7+** (`pwsh`)
- (선택) **Ollama** + 모델 1개 — 자동 정리를 쓰려면. 없어도 양식 모드로 동작.

## 업로드는 없습니다

이 키트는 **로컬에 .md 파일을 만들어 줄 뿐**, 어디에도 자동 발행/업로드하지 않습니다.
정리된 글을 블로그에 올릴지 말지는 전적으로 사용자 몫입니다.
