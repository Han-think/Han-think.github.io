#Requires -Version 7.0
<#
.SYNOPSIS
    DailyLog Kit — turn a quick brain-dump into a tidy daily log (text vlog), by category.
    하루 메모를 카테고리별 '포인트'로 정리해주는 텍스트 브이로그 양식 채우기 키트.

.DESCRIPTION
    - Pick categories → drop a free-form memo → (optional) local LLM organizes it into points → saved as Markdown.
    - Works WITHOUT an LLM too: it just produces an empty template for you to fill in.
    - No upload / no deploy — pure local note tidying.

.PARAMETER Date     yyyy-MM-dd (default: today)
.PARAMETER Model    Ollama model name (default: gemma3:12b)
.PARAMETER OutDir   where to save (default: <kit>\output)
.PARAMETER NoOpen   don't auto-open the file
.PARAMETER NoLLM    skip LLM, empty template only
#>
param(
    [string]$Date = (Get-Date).ToString("yyyy-MM-dd"),
    [string]$Model = "gemma3:12b",
    [string]$OutDir = (Join-Path $PSScriptRoot "output"),
    [switch]$NoOpen,
    [switch]$NoLLM
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$OllamaBase = "http://127.0.0.1:11434"

# ── Categories (edit freely: emoji + name) ──
$CATS = @(
    @{ emoji = "📚"; name = "학습" },
    @{ emoji = "💻"; name = "개발" },
    @{ emoji = "🍳"; name = "요리" },
    @{ emoji = "🏃"; name = "운동" },
    @{ emoji = "📖"; name = "독서" },
    @{ emoji = "🎵"; name = "음악" },
    @{ emoji = "🎮"; name = "게임" },
    @{ emoji = "🌿"; name = "일상" },
    @{ emoji = "💡"; name = "생각" }
)

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  DailyLog Kit  —  $Date" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

# ── pick categories ──
Write-Host ""
Write-Host "  기록할 요소를 고르세요 (쉼표로 여러 개, 예: 1,3,8)" -ForegroundColor Yellow
for ($i = 0; $i -lt $CATS.Count; $i++) {
    Write-Host ("    [{0}] {1} {2}" -f ($i + 1), $CATS[$i].emoji, $CATS[$i].name)
}
$sel = (Read-Host "  번호").Trim()
if ($sel -eq "") { Write-Host "  취소됨." -ForegroundColor DarkGray; exit 0 }
$picked = @($sel -split "," | ForEach-Object { [int]$_.Trim() - 1 } | Where-Object { $_ -ge 0 -and $_ -lt $CATS.Count } | ForEach-Object { $CATS[$_] })
if ($picked.Count -eq 0) { Write-Host "  선택 없음." -ForegroundColor Yellow; exit 0 }

# ── free memo (multi-line, blank line ends) ──
Write-Host ""
Write-Host "  오늘 있었던 일을 자유롭게 적으세요. (여러 줄 OK, 빈 줄=끝 / 그냥 엔터=수동작성)" -ForegroundColor Yellow
$memoLines = [System.Collections.Generic.List[string]]::new()
while ($true) { $line = Read-Host "  >"; if ($line -eq "") { break }; $memoLines.Add($line) }
$memo = ($memoLines -join "`n").Trim()

# ── LLM (optional) ──
$ollamaOk = $false
if (-not $NoLLM -and $memo -ne "") {
    try { $null = Invoke-RestMethod "$OllamaBase/api/tags" -TimeoutSec 4; $ollamaOk = $true } catch { $ollamaOk = $false }
    if (-not $ollamaOk) { Write-Host "  (Ollama 꺼짐 → 빈 양식으로 생성)" -ForegroundColor DarkGray }
}
function Invoke-LLM {
    param([string]$Prompt)
    $body = [ordered]@{ model = $Model; prompt = $Prompt; stream = $false; options = [ordered]@{ num_predict = 512; num_ctx = 8192; temperature = 0.4 } }
    $bytes = [System.Text.Encoding]::UTF8.GetBytes(($body | ConvertTo-Json -Depth 4 -Compress))
    try { return ([string](Invoke-RestMethod -Uri "$OllamaBase/api/generate" -Method Post -Body $bytes -ContentType "application/json; charset=utf-8" -TimeoutSec 120).response).Trim() }
    catch { return "" }
}

# ── build ──
$sb = [System.Collections.Generic.List[string]]::new()
$tagList = ($picked | ForEach-Object { '"' + $_.name + '"' }) -join ", "
$sb.Add("---")
$sb.Add('title: "' + $Date + ' 데일리 로그"')
$sb.Add("date: $Date")
$sb.Add('categories: ["daily"]')
$sb.Add("tags: [$tagList]")
$sb.Add("---")
$sb.Add("")
$sb.Add("## 오늘의 포인트")
foreach ($c in $picked) {
    if ($ollamaOk) {
        $p = @"
다음은 하루 메모다. 이 중 '$($c.name)' 와 관련된 내용만 1~3개의 짧은 포인트로 정리하라.
규칙: 각 포인트는 한 줄, 간결한 한국어, 머리말/설명/번호 없이 내용만. 관련 내용이 없으면 아무것도 출력하지 마라.

메모:
---
$memo
"@
        $resp = Invoke-LLM $p
        $points = @($resp -split "`r?`n" | ForEach-Object { ($_ -replace '^\s*[-*\d\.\)]+\s*', '').Trim() } | Where-Object { $_ })
        if ($points.Count -eq 1) { $sb.Add(("- {0} {1}: {2}" -f $c.emoji, $c.name, $points[0])) }
        elseif ($points.Count -gt 1) { $sb.Add(("- {0} {1}:" -f $c.emoji, $c.name)); foreach ($pt in $points) { $sb.Add("  - $pt") } }
        else { $sb.Add(("- {0} {1}: " -f $c.emoji, $c.name)) }
    } else { $sb.Add(("- {0} {1}: " -f $c.emoji, $c.name)) }
}
$sb.Add("")
$sb.Add("## 한 줄 회고")
$retro = ""
if ($ollamaOk) { $retro = Invoke-LLM "다음 하루 메모를 바탕으로 '오늘 하루'를 한 줄로 담백하게 회고하라. 한 문장, 사족 없이.`n`n메모:`n---`n$memo" }
$sb.Add($(if ($retro) { $retro } else { "" }))
$sb.Add("")

# ── save ──
if (-not (Test-Path -LiteralPath $OutDir)) { New-Item -ItemType Directory -Path $OutDir -Force | Out-Null }
$outPath = Join-Path $OutDir "$Date-daily.md"
[System.IO.File]::WriteAllText($outPath, ($sb -join "`n"), [System.Text.Encoding]::UTF8)

Write-Host ""
Write-Host ("  저장: {0}" -f $outPath) -ForegroundColor Green
Write-Host ("  카테고리: {0}  |  LLM 정리: {1}" -f (($picked | ForEach-Object { $_.emoji + $_.name }) -join " "), $(if ($ollamaOk) { "사용" } else { "미사용" })) -ForegroundColor DarkGray
Write-Host "========================================" -ForegroundColor Cyan
if (-not $NoOpen) { Start-Process $outPath }
exit 0
