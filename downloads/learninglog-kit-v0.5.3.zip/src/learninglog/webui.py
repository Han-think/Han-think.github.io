"""webui — 브라우저 기반 설치/설정/실행 UI (learninglog ui).

아무나 설치 후 'learninglog ui' 한 줄이면:
  - 작업 폴더 생성/선택
  - LLM provider 설정 (Gemini 기본 안내)
  - API 키 입력 + 연결 테스트
  - 노트 처리 / 블로그 발행을 버튼으로 실행

의존성: pip install "learninglog-kit[web]"  (fastapi, uvicorn)
"""

import csv
import os
import shutil
import subprocess
import sys
import threading
import webbrowser
from pathlib import Path

from .config import find_config, load_config


# ─────────────────────────────────────────────────────────
# Gemini 우선 provider 안내 데이터
# ─────────────────────────────────────────────────────────
PROVIDERS = {
    "gemini": {
        "name": "Gemini (Google) — 무료 추천",
        "url": "https://aistudio.google.com/app/apikey",
        "hint": "구글 계정으로 로그인 → Create API key → 키 복사 (AIza... 또는 AQ... 둘 다 지원)",
        "needs_key": True, "default_model": "gemini-2.5-flash",
    },
    "groq": {
        "name": "Groq — 무료 (초고속)",
        "url": "https://console.groq.com",
        "hint": "무료 가입 → API Keys → Create → gsk_... 복사",
        "needs_key": True, "default_model": "llama-3.1-8b-instant",
    },
    "ollama": {
        "name": "Ollama — 완전 무료 (로컬)",
        "url": "https://ollama.com",
        "hint": "Ollama 설치 후: ollama pull gemma3:4b / ollama serve",
        "needs_key": False, "default_model": "gemma3:4b",
    },
}


def _html() -> str:
    return """<!doctype html>
<html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>LearningLog 설정</title>
<style>
  :root { --bg:#1a1713; --fg:#f5ede0; --acc:#c49a4a; --mut:#7a6e62; --card:#23201a; --line:#352e24; }
  * { box-sizing:border-box; }
  body { margin:0; font-family:'Noto Sans KR',system-ui,sans-serif; background:var(--bg); color:var(--fg); line-height:1.6; }
  .wrap { max-width:720px; margin:0 auto; padding:2rem 1.2rem 4rem; }
  h1 { font-size:1.5rem; margin:.2rem 0; }
  h2 { font-size:1.05rem; border-left:3px solid var(--acc); padding-left:.6rem; margin:2rem 0 .8rem; }
  .sub { color:var(--mut); font-size:.9rem; margin-top:0; }
  .card { background:var(--card); border:1px solid var(--line); border-radius:10px; padding:1.2rem; margin-bottom:1rem; }
  label { display:block; font-size:.85rem; color:var(--mut); margin:.6rem 0 .2rem; }
  input, select { width:100%; padding:.6rem .7rem; background:var(--bg); color:var(--fg);
    border:1px solid var(--line); border-radius:7px; font-size:.95rem; }
  .prov { display:flex; gap:.5rem; flex-wrap:wrap; margin:.4rem 0; }
  .prov button { flex:1; min-width:150px; text-align:left; padding:.7rem; cursor:pointer;
    background:var(--bg); border:1px solid var(--line); border-radius:8px; color:var(--fg); }
  .prov button.on { border-color:var(--acc); background:#2d2718; }
  .prov .pn { font-weight:600; font-size:.9rem; }
  .prov .pu { color:var(--mut); font-size:.75rem; margin-top:.2rem; word-break:break-all; }
  button.act { background:var(--acc); color:#1a1713; border:none; border-radius:8px;
    padding:.7rem 1.1rem; font-weight:700; cursor:pointer; font-size:.95rem;
    transition:transform .06s ease, filter .12s ease, box-shadow .12s ease;
    box-shadow:0 2px 0 #8a6c2e; }
  button.act:hover { filter:brightness(1.08); }
  button.act:active { transform:translateY(2px); box-shadow:0 0 0 #8a6c2e; }
  button.act:disabled { opacity:.5; cursor:default; box-shadow:none; transform:none; }
  button.ghost { background:var(--card); color:var(--fg); border:1px solid var(--line);
    border-radius:8px; padding:.6rem 1rem; cursor:pointer; font-weight:600;
    transition:transform .06s ease, background .12s ease, border-color .12s ease, box-shadow .12s ease;
    box-shadow:0 2px 0 #14110d; }
  button.ghost:hover { background:#2d2718; border-color:var(--acc); color:var(--acc); }
  button.ghost:active { transform:translateY(2px); box-shadow:0 0 0 #14110d; background:#3a3220; }
  .row { display:flex; gap:.6rem; flex-wrap:wrap; align-items:center; margin-top:.8rem; }
  .hint { font-size:.82rem; color:var(--mut); margin-top:.4rem; }
  .hint a { color:var(--acc); }
  .danger { color:#ffd27d; background:#3a2718; border:1px solid #7a4d1e; padding:.65rem; border-radius:8px; font-size:.84rem; }
  .stat { display:flex; gap:1.5rem; flex-wrap:wrap; }
  .stat div { text-align:center; }
  .stat .n { font-size:1.6rem; font-weight:700; color:var(--acc); }
  .stat .l { font-size:.75rem; color:var(--mut); }
  pre { background:#000; color:#ccc; padding:.9rem; border-radius:8px; font-size:.78rem;
    max-height:320px; overflow:auto; white-space:pre-wrap; }
  .ok { color:#7bbf7b; } .err { color:#cf6679; } .warn { color:#d4b04a; }
  .pill { display:inline-block; padding:.15rem .55rem; border-radius:20px; font-size:.72rem; border:1px solid var(--line); }
  .pv { margin-top:.8rem; border:1px solid var(--line); border-radius:8px; overflow:hidden; }
  .pvh { background:#2d2718; padding:.5rem .7rem; font-size:.82rem; font-weight:600; display:flex; gap:.5rem; align-items:center; justify-content:space-between; }
  .pv pre { margin:0; border-radius:0; max-height:280px; }
</style></head>
<body><div class="wrap">
  <h1>LearningLog <span style="color:var(--acc)">설정</span></h1>
  <p class="sub">설치 → 위치 → API키 → 실행. 브라우저에서 버튼으로 끝.</p>

  <h2>1. 작업 폴더</h2>
  <div class="card">
    <div id="proj"></div>
    <div class="hint">강의자료는 <code>00_inbox/lectures/</code>, 개인노트(.md)는 <code>00_inbox/personal_notes/</code> 에 넣습니다.</div>
    <div class="row"><button class="ghost" onclick="initFolders()">이 위치에 폴더 구조 생성</button></div>
  </div>

  <h2>2. LLM 선택 + API 키</h2>
  <div class="card">
    <div class="danger">API 키는 편의를 위해 config.yaml에 저장됩니다. 이 파일을 GitHub, 메신저, 블로그에 올리지 마세요.</div>
    <div class="prov" id="provs"></div>
    <div id="keybox">
      <label>API 키 붙여넣기</label>
      <input id="apikey" type="password" placeholder="여기에 API 키 붙여넣기" autocomplete="off">
      <div class="hint" id="keyhint"></div>
    </div>
    <div class="row">
      <button class="act" onclick="saveCfg()">저장 + 연결 테스트</button>
      <span id="savestat"></span>
    </div>
  </div>

  <h2>3. 블로그 + GitHub 연결</h2>
  <div class="card">
    <label>블로그 소스 폴더</label>
    <input id="blogpath" placeholder="../blog-source 또는 C:\\path\\to\\blog">
    <label>GitHub 저장소 주소</label>
    <input id="repo" placeholder="https://github.com/USER/REPO">
    <label>GitHub Pages 주소</label>
    <input id="pages" placeholder="https://USER.github.io/">
    <label><input id="autopush" type="checkbox" style="width:auto;margin-right:.4rem"> GitHub push 버튼 사용</label>
    <div class="hint">publish는 글 복사/빌드까지만 실행합니다. GitHub 업로드는 아래 push 버튼을 직접 누를 때만 실행됩니다.</div>
    <div class="row">
      <button class="act" onclick="saveBlog()">블로그 설정 저장</button>
      <span id="blogstat"></span>
    </div>
  </div>

  <h2>4. 상태 체크</h2>
  <div class="card">
    <div id="checks" class="hint">확인 중...</div>
  </div>

  <h2>5. 실행</h2>
  <div class="card">
    <div class="stat" id="stat"><div><div class="n">–</div><div class="l">전체</div></div></div>
    <div class="row">
      <button class="ghost" onclick="run('intake', this)">① intake 등록</button>
      <button class="ghost" onclick="run('extract', this)">② extract 처리</button>
      <button class="ghost" onclick="preview(this)">③ 미리보기 👁</button>
      <button class="act" onclick="run('publish', this)">④ publish 발행 🚀</button>
      <button class="ghost" onclick="run('push', this)">⑤ GitHub push</button>
      <button class="ghost" onclick="loadStatus()">↻ 새로고침</button>
    </div>
    <div class="hint">발행 전 <b>③ 미리보기</b>로 실제 나갈 모습(AI 고지 footer·draft 해제·내부 메타 제거)을 확인하세요. <b>④ publish</b>는 블로그 폴더로 복사 + 빌드를 실제로 실행합니다.</div>
    <div class="row" style="display:block"><pre id="out">대기 중...</pre></div>
    <div id="preview"></div>
  </div>
</div>
<script>
let provider = "gemini";
let provData = {};

async function boot() {
  const r = await fetch('/api/info'); const d = await r.json();
  provData = d.providers; provider = d.current_provider || "gemini";
  document.getElementById('proj').innerHTML =
    `<span class="pill">📁 ${d.project_dir}</span> ` +
    (d.has_config ? '<span class="pill ok">설정됨</span>' : '<span class="pill warn">미설정</span>');
  document.getElementById('blogpath').value = d.blog.source_path || '';
  document.getElementById('repo').value = d.blog.github_repo_url || '';
  document.getElementById('pages').value = d.blog.pages_url || '';
  document.getElementById('autopush').checked = !!d.blog.auto_push;
  const pe = document.getElementById('provs'); pe.innerHTML = '';
  for (const [k,v] of Object.entries(provData)) {
    const b = document.createElement('button');
    b.className = (k===provider ? 'on' : '');
    b.dataset.k = k;
    b.innerHTML = `<div class="pn">${v.name}</div><div class="pu">${v.url}</div>`;
    b.onclick = ()=>{ provider=k; document.querySelectorAll('#provs button').forEach(x=>x.classList.remove('on')); b.classList.add('on'); renderKey(); };
    pe.appendChild(b);
  }
  renderKey(); loadStatus();
}
function renderKey() {
  const v = provData[provider];
  document.getElementById('keybox').style.display = v.needs_key ? 'block' : 'none';
  document.getElementById('keyhint').innerHTML = v.needs_key
    ? `발급: <a href="${v.url}" target="_blank">${v.url}</a> — ${v.hint}`
    : v.hint;
}
async function initFolders() {
  setOut('폴더 생성 중...');
  const r = await fetch('/api/init', {method:'POST'}); const d = await r.json();
  setOut(d.output); boot();
}
async function saveCfg() {
  const key = document.getElementById('apikey').value.trim();
  document.getElementById('savestat').textContent = '저장+테스트 중...';
  const r = await fetch('/api/setup', {method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({provider, api_key:key})});
  const d = await r.json();
  document.getElementById('savestat').innerHTML = d.ok
    ? '<span class="ok">✓ '+d.msg+'</span>' : '<span class="err">✗ '+d.msg+'</span>';
}
async function saveBlog() {
  document.getElementById('blogstat').textContent = '저장 중...';
  const body = {
    source_path: document.getElementById('blogpath').value.trim(),
    github_repo_url: document.getElementById('repo').value.trim(),
    pages_url: document.getElementById('pages').value.trim(),
    auto_push: document.getElementById('autopush').checked
  };
  const r = await fetch('/api/blog', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body)});
  const d = await r.json();
  document.getElementById('blogstat').innerHTML = d.ok
    ? '<span class="ok">✓ '+d.msg+'</span>' : '<span class="err">✗ '+d.msg+'</span>';
  loadStatus();
}
async function run(step, btn) {
  const all = document.querySelectorAll('#stat ~ .row button, .card .row button.ghost');
  all.forEach(b=>b.disabled = true);
  let label;
  if (btn) { label = btn.textContent; btn.textContent = '⏳ '+step+' 실행 중...'; btn.style.opacity = .7; }
  setOut('▶ '+step+' 실행 중... (모델 로딩에 시간이 걸릴 수 있음)');
  try {
    const r = await fetch('/api/run/'+step, {method:'POST'}); const d = await r.json();
    setOut(d.output); loadStatus();
  } catch (e) {
    setOut('✗ 실행 실패: '+e);
  } finally {
    all.forEach(b=>b.disabled = false);
    if (btn) { btn.textContent = label; btn.style.opacity = 1; }
  }
}
async function loadStatus() {
  const r = await fetch('/api/status'); const d = await r.json();
  document.getElementById('stat').innerHTML =
    `<div><div class="n">${d.total}</div><div class="l">전체 소스</div></div>
     <div><div class="n">${d.pending}</div><div class="l">대기</div></div>
     <div><div class="n">${d.drafted}</div><div class="l">초안</div></div>
     <div><div class="n">${d.published}</div><div class="l">발행</div></div>`;
  document.getElementById('checks').innerHTML =
    d.checks.map(x => `<div>${x.ok ? '<span class="ok">✓</span>' : '<span class="warn">!</span>'} ${x.name}: ${x.detail}</div>`).join('');
}
function setOut(t){ document.getElementById('out').textContent = t; }
function esc(s){ return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
async function preview(btn) {
  const all = document.querySelectorAll('#stat ~ .row button, .card .row button.ghost, .card .row button.act');
  all.forEach(b=>b.disabled = true);
  const label = btn ? btn.textContent : '';
  if (btn) { btn.textContent = '⏳ 미리보기...'; }
  document.getElementById('preview').innerHTML = '';
  setOut('▶ 발행 미리보기 생성 중...');
  try {
    const r = await fetch('/api/preview', {method:'POST'}); const d = await r.json();
    if (d.error) { setOut('✗ 미리보기 실패: '+d.error); return; }
    if (!d.items || !d.items.length) {
      setOut('미리볼 초안이 없습니다. 먼저 ② extract 로 초안을 생성하세요.'); return;
    }
    let html = '';
    for (const it of d.items) {
      const badge = it.publishable
        ? '<span class="pill ok">✓ 발행 가능</span>'
        : '<span class="pill err">✗ 발행 차단: '+esc(it.blocked_reason)+'</span>';
      html += `<div class="pv"><div class="pvh">${esc(it.section)}/${esc(it.name)} ${badge}</div><pre>${esc(it.content)}</pre></div>`;
    }
    document.getElementById('preview').innerHTML = html;
    const blocked = d.items.filter(x=>!x.publishable).length;
    setOut(`미리보기 ${d.items.length}개 — 발행 가능 ${d.items.length-blocked}, 차단 ${blocked}. 아래에서 AI footer/내용 확인 후 ④ publish 하세요.`);
  } catch (e) {
    setOut('✗ 미리보기 실패: '+e);
  } finally {
    all.forEach(b=>b.disabled = false);
    if (btn) { btn.textContent = label; }
  }
}
boot();
</script>
</body></html>"""


def create_app(project_dir: Path):
    try:
        from fastapi import FastAPI, Request
        from fastapi.responses import HTMLResponse, JSONResponse
    except ImportError:
        raise ImportError('웹 UI에는 추가 설치가 필요합니다: pip install "learninglog-kit[web]"')

    app = FastAPI(title="LearningLog UI")

    def _cfg_path() -> Path:
        return project_dir / ".learninglog" / "config.yaml"

    @app.get("/", response_class=HTMLResponse)
    def index():
        return _html()

    @app.get("/api/info")
    def info():
        cfg = load_config(_cfg_path()) if _cfg_path().exists() else {}
        return JSONResponse({
            "project_dir": str(project_dir),
            "has_config": _cfg_path().exists(),
            "current_provider": cfg.get("llm", {}).get("provider", "gemini"),
            "providers": PROVIDERS,
            "blog": cfg.get("blog", {}),
        })

    @app.post("/api/init")
    def api_init():
        out = _run_cmd(["init", str(project_dir)], skip_wizard=True)
        return JSONResponse({"output": out})

    @app.post("/api/setup")
    async def api_setup(request: Request):
        ENV_NAMES = {"gemini": "GEMINI_API_KEY", "groq": "GROQ_API_KEY",
                     "claude": "ANTHROPIC_API_KEY", "openai": "OPENAI_API_KEY"}
        body = await request.json()
        prov = body.get("provider", "gemini")
        typed = (body.get("api_key") or "").strip()
        info = PROVIDERS.get(prov, {})

        # 입력칸 비었으면 환경변수 키(GEMINI_API_KEY 등)를 자동 사용
        env_key  = os.environ.get(ENV_NAMES.get(prov, ""), "")
        from_env = (not typed) and bool(env_key)
        test_key = typed or env_key

        # config.yaml 보장
        if not _cfg_path().exists():
            _run_cmd(["init", str(project_dir)], skip_wizard=True)

        # 키 검사 (입력도 환경변수도 없으면 안내)
        if info.get("needs_key") and not test_key:
            return JSONResponse({"ok": False, "msg": "API 키를 입력하세요."})

        ok, msg, picked = _test(prov, test_key, info.get("default_model", ""))

        # config 저장: 입력한 키만 저장(환경변수 키는 저장 안 함 → 런타임에 환경변수 사용)
        from .setup_wizard import _update_config
        extra = {"host": "http://127.0.0.1:11434", "num_ctx": 4096} if prov == "ollama" else None
        save_key = None if not info.get("needs_key") else (typed if typed else "")
        _update_config(_cfg_path(), prov, api_key=save_key,
                       model=(picked or info.get("default_model", "")), extra=extra)

        if ok and from_env:
            msg += "  (환경변수 키 사용)"
        return JSONResponse({"ok": ok, "msg": msg})

    @app.post("/api/blog")
    async def api_blog(request: Request):
        body = await request.json()
        if not _cfg_path().exists():
            _run_cmd(["init", str(project_dir)], skip_wizard=True)
        _update_blog_config(
            _cfg_path(),
            source_path=(body.get("source_path") or "").strip(),
            github_repo_url=(body.get("github_repo_url") or "").strip(),
            pages_url=(body.get("pages_url") or "").strip(),
            auto_push=bool(body.get("auto_push")),
        )
        return JSONResponse({"ok": True, "msg": "블로그/GitHub 설정 저장 완료"})

    @app.get("/api/status")
    def status():
        return JSONResponse(_status(project_dir))

    @app.post("/api/run/{step}")
    def run_step(step: str):
        if step not in ("intake", "extract", "publish", "queue", "push"):
            return JSONResponse({"output": "알 수 없는 단계: " + step})
        return JSONResponse({"output": _run_cmd([step])})

    @app.post("/api/preview")
    def api_preview():
        """발행 미리보기 — 실제 복사/빌드 없이 최종 본문(AI footer 포함)을 반환."""
        from .publish import collect_publish_preview
        cfg = load_config(_cfg_path()) if _cfg_path().exists() else {}
        try:
            items = collect_publish_preview(cfg)
        except Exception as e:
            return JSONResponse({"items": [], "error": str(e)})
        return JSONResponse({"items": items})

    def _run_cmd(args: list[str], skip_wizard: bool = False) -> str:
        env = dict(os.environ)
        if skip_wizard:
            env["LEARNINGLOG_NO_WIZARD"] = "1"
        try:
            r = subprocess.run([sys.executable, "-m", "learninglog", *args],
                               cwd=str(project_dir), capture_output=True, text=True,
                               timeout=1800, env=env, encoding="utf-8", errors="replace")
            return (r.stdout or "") + (("\n[stderr]\n" + r.stderr) if r.stderr.strip() else "")
        except Exception as e:
            return f"실행 오류: {e}"

    return app


def _update_blog_config(
    config_path: Path,
    source_path: str,
    github_repo_url: str,
    pages_url: str,
    auto_push: bool,
) -> None:
    import yaml

    with open(config_path, encoding="utf-8") as f:
        cfg = yaml.safe_load(f) or {}
    blog = cfg.setdefault("blog", {})
    blog["platform"] = "hugo" if source_path else blog.get("platform", "none")
    blog["source_path"] = source_path
    blog["github_repo_url"] = github_repo_url
    blog["pages_url"] = pages_url
    blog.setdefault("content_subdir", "content")
    blog.setdefault("auto_build", True)
    blog["auto_push"] = auto_push
    with open(config_path, "w", encoding="utf-8") as f:
        yaml.dump(cfg, f, allow_unicode=True, default_flow_style=False, sort_keys=False)


def _test(provider: str, key: str, model: str):
    """반환: (성공여부, 메시지, 자동선택모델). 모델은 gemini/groq 만 채워질 수 있음."""
    try:
        if provider == "gemini":
            from google import genai
            client = genai.Client(api_key=key) if key else genai.Client()
            mdl = model or "gemini-2.5-flash"
            # 실제 생성 호출로 키 검증 (새 SDK, AQ. 키 지원)
            client.models.generate_content(model=mdl, contents="hi")
            return True, f"연결 성공 — 모델: {mdl}", mdl

        elif provider == "groq":
            from groq import Groq
            client = Groq(api_key=key)
            models = [m.id for m in client.models.list().data]
            if not models:
                return False, "사용 가능한 모델이 없습니다.", ""
            pick = next((m for m in models if "llama" in m and "instant" in m), None) or models[0]
            return True, f"연결 성공 — 모델: {pick}", pick

        elif provider == "ollama":
            import httpx
            httpx.get("http://127.0.0.1:11434/", timeout=3)
            return True, "Ollama 연결 성공", ""

        return False, "알 수 없는 provider", ""
    except ImportError:
        return False, f'라이브러리 미설치: pip install "learninglog-kit[{provider}]"', ""
    except Exception as e:
        msg = str(e)
        if "API_KEY_INVALID" in msg or "API key not valid" in msg or "401" in msg or "403" in msg or "PERMISSION" in msg:
            return False, "API 키가 올바르지 않습니다. AI Studio 키를 다시 확인하세요.", ""
        return False, f"연결 실패: {msg[:140]}", ""


def _status(project_dir: Path) -> dict:
    reg = project_dir / "01_registry" / "source_registry.csv"
    s = {"total": 0, "pending": 0, "drafted": 0, "published": 0, "checks": _checks(project_dir)}
    if reg.exists():
        with open(reg, encoding="utf-8") as f:
            for row in csv.DictReader(f):
                s["total"] += 1
                st = row.get("status", "")
                if st in ("registered", "new"): s["pending"] += 1
                elif st == "drafted": s["drafted"] += 1
                elif st == "published": s["published"] += 1
    return s


def _checks(project_dir: Path) -> list[dict]:
    cfg_path = project_dir / ".learninglog" / "config.yaml"
    cfg = load_config(cfg_path) if cfg_path.exists() else {}
    provider = cfg.get("llm", {}).get("provider", "none")
    blog = cfg.get("blog", {})
    source_path = blog.get("source_path", "")
    blog_root = Path(source_path) if source_path else Path("")
    if source_path and not blog_root.is_absolute():
        blog_root = (project_dir / source_path).resolve()

    return [
        {"name": "Python", "ok": True, "detail": sys.version.split()[0]},
        {"name": "config.yaml", "ok": cfg_path.exists(), "detail": str(cfg_path) if cfg_path.exists() else "없음"},
        {"name": "LLM provider", "ok": provider != "none", "detail": provider},
        {"name": "Hugo", "ok": bool(shutil.which("hugo")), "detail": shutil.which("hugo") or "명령 없음"},
        {"name": "Blog path", "ok": bool(source_path and blog_root.exists()), "detail": str(blog_root) if source_path else "미설정"},
        {"name": "Git repo", "ok": bool(source_path and (blog_root / ".git").exists()), "detail": str(blog_root / ".git") if source_path else "미설정"},
        {"name": "GitHub URL", "ok": bool(blog.get("github_repo_url")), "detail": blog.get("github_repo_url") or "미설정"},
        {"name": "Pages URL", "ok": bool(blog.get("pages_url")), "detail": blog.get("pages_url") or "미설정"},
    ]


def run_ui(host: str = "127.0.0.1", port: int = 8765, project_dir: Path | None = None) -> None:
    try:
        import uvicorn
    except ImportError:
        raise ImportError('웹 UI에는 추가 설치가 필요합니다: pip install "learninglog-kit[web]"')

    pdir = project_dir or Path.cwd()
    cf = find_config(pdir)
    if cf:
        pdir = cf.parent.parent

    app = create_app(pdir)
    url = f"http://{host}:{port}"
    threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    print(f"\n  LearningLog UI → {url}\n  (종료: Ctrl+C)\n")
    uvicorn.run(app, host=host, port=port, log_level="warning")
