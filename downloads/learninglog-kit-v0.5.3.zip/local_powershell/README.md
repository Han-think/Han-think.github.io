# LearningLog Windows Local Runner

This folder contains the Windows PowerShell version of LearningLog. It is the full local workflow for turning raw study material into reviewed blog drafts and approved posts.

## Start

Run:

```powershell
.\LearningLog.bat
```

The batch file opens the PowerShell launcher:

```text
learninglog_launch.ps1
```

## Main Flow

Use the menu in this order:

```text
[1] intake
[2] prep
[3] extract
[4] blogdraft
[A] approve
[V] preview
[5] publish
```

Short version:

- `intake` registers new source files.
- `prep` builds LLM prep packets.
- `extract` uses the configured LLM flow to classify, extract, and create notes.
- `blogdraft` creates publishable blog drafts.
- `approve` moves QA-passing drafts into `05_ready_to_publish`.
- `preview` generates the local review dashboard.
- `publish` copies approved posts into the configured blog source and runs the publish flow.

## Folder Structure

The runner expects this workspace layout:

```text
00_inbox              raw source files
01_registry           CSV registry and source tracking
02_extracted          extracted factual summaries
03_working_notes      personal learning notes
04_blog_drafts        Hugo-style blog drafts
05_ready_to_publish   approved posts waiting for publish
06_published          local copies after publish
07_archive            archived processed material
08_templates          Markdown and CSV templates
09_reports            generated reports, previews, prep packets
_local_core           shared PowerShell module and local assets
```

## Preview Notes

Version 0.5.3 fixes the preview dashboard when only one draft is visible. The dashboard now keeps its embedded data as an array for zero, one, or many drafts, and it guards one-item badge data in the browser UI.

Daily combined posts also show the member source notes in the original-note pane. This prevents the left pane from showing the daily draft itself as if it were the original note.

Preview and approval exclude byproduct drafts by default. Use `-IncludeByproducts` only when you intentionally want to inspect partial side products.

If already-published drafts are hidden, run:

```powershell
.\run_learninglog_preview.ps1 -IncludePublished
```

## Publish Safety

Before publishing, the script checks the final destination path:

```text
blog-source/content/{section}/{filename}.md
```

It then shows new additions and existing updates. If any existing post will be updated, publish asks for confirmation before copying, building, or pushing anything.

## Unpublish

The unpublish script can remove an already-published post by list selection, file name, slug, or published URL.

## Notes

- Keep `00_inbox` source files immutable.
- Copying into `blog-source/content` should happen only through the explicit publish step.
- Keep `.learninglog/config.yaml` and any API keys outside redistributable zips.
- This runner is Windows-first and expects PowerShell 7.
