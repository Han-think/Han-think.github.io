#Requires -Version 7.0
<#
.SYNOPSIS
    LearningLog 런처 — 파이프라인 메뉴 + Ollama 서버 관리
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = "SilentlyContinue"
Import-Module (Join-Path $PSScriptRoot "_local_core\LearningLog.LocalCore.psm1") -Force -DisableNameChecking

$Root         = Get-LLRoot
$RegistryPath = Get-LLRegistryPath
$PrepDir      = Get-LLPath "09_reports\llm_prep"
$OllamaExe    = "C:\Ollama-IPEX\ollama.exe"
$OllamaBase   = "http://127.0.0.1:11434"

# ─────────────────────────────────────────────────────────
# 헬퍼
# ─────────────────────────────────────────────────────────
function Test-OllamaRunning {
    try {
        $null = Invoke-RestMethod -Uri "$OllamaBase/" -Method Get -TimeoutSec 2 -ErrorAction Stop
        return $true
    } catch { return $false }
}

function Get-PipelineStatus {
    $s = @{ total = 0; pending = 0; immediate = 0; drafted = 0; published = 0; internal = 0; prep = 0; ollama = $false }
    if (Test-Path $RegistryPath) {
        $null = Ensure-LLRegistrySchema
        $rows = Get-LLRegistryRows
        $s.total     = $rows.Count
        $s.pending   = @($rows | Where-Object { $_.status -in @("registered","new") }).Count
        $s.immediate = @($rows | Where-Object { $_.status -in @("registered","new") -and (Test-LLMProcessableSource $_) }).Count
        $s.drafted   = @($rows | Where-Object { $_.status -eq "drafted" }).Count
        $s.published = @($rows | Where-Object { $_.status -eq "published" }).Count
        $s.internal  = @($rows | Where-Object { $_.public_policy -eq "internal-only" }).Count
    }
    if (Test-Path $PrepDir) {
        $s.prep = @(Get-ChildItem $PrepDir -Filter "PREP_*.md" -File).Count
    }
    $s.ollama = Test-OllamaRunning
    return $s
}

function Start-OllamaServer {
    if (-not (Test-Path $OllamaExe)) {
        Write-Host ""
        Write-Host ("  [ERROR] ollama.exe 없음: {0}" -f $OllamaExe) -ForegroundColor Red
        Start-Sleep -Seconds 2
        return
    }
    Write-Host ""
    Write-Host "  Ollama 서버 시작 중 ..." -ForegroundColor Yellow
    Start-Process -FilePath $OllamaExe -ArgumentList "serve" -WindowStyle Normal
    Write-Host "  잠시 대기 (3초) ..." -ForegroundColor DarkGray
    Start-Sleep -Seconds 3
    if (Test-OllamaRunning) {
        Write-Host "  Ollama 서버 시작 완료  (127.0.0.1:11434)" -ForegroundColor Green
    } else {
        Write-Host "  아직 준비 중일 수 있습니다. 잠시 후 [3] extract 를 시도하세요." -ForegroundColor Yellow
    }
    Write-Host ""
    Write-Host "  아무 키나 누르면 메뉴로 돌아갑니다..." -ForegroundColor DarkGray
    $null = [Console]::ReadKey($true)
}

function Show-Menu {
    $s   = Get-PipelineStatus
    $now = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

    $ollamaLabel = if ($s.ollama) { "ON  (127.0.0.1:11434)" } else { "OFF" }
    $ollamaColor = if ($s.ollama) { "Green" } else { "Red" }
    $prepColor   = if ($s.prep -gt 0) { "Yellow" } else { "DarkGray" }
    $extractColor = if ($s.ollama -and $s.prep -gt 0) { "Magenta" } else { "DarkGray" }

    Clear-Host
    Write-Host ""
    Write-Host "  +------------------------------------------+" -ForegroundColor Cyan
    Write-Host "  |       LearningLog Launcher               |" -ForegroundColor Cyan
    Write-Host ("  |       {0}               |" -f $now) -ForegroundColor DarkGray
    Write-Host "  +------------------------------------------+" -ForegroundColor Cyan
    Write-Host ("  |  전체:{0,3} 대기:{1,3} 즉시:{2,3} 초안:{3,3}    |" -f `
        $s.total, $s.pending, $s.immediate, $s.drafted) -ForegroundColor White
    Write-Host ("  |  발행:{0,3} internal-only:{1,3}                 |" -f `
        $s.published, $s.internal) -ForegroundColor DarkGray
    Write-Host ("  |  PREP 패킷 대기: {0,2} 개                    |" -f $s.prep) -ForegroundColor $prepColor
    Write-Host -NoNewline "  |  Ollama: " -ForegroundColor White
    Write-Host -NoNewline $ollamaLabel -ForegroundColor $ollamaColor
    $pad = 32 - $ollamaLabel.Length
    Write-Host (" " * $pad + "|") -ForegroundColor White
    Write-Host "  +------------------------------------------+" -ForegroundColor Cyan
    Write-Host "  |                                          |" -ForegroundColor DarkGray
    Write-Host "  |  [0]  Ollama 서버 시작                    |" -ForegroundColor $(if ($s.ollama) { "DarkGray" } else { "Yellow" })
    Write-Host "  |  ---------------------------------------- |" -ForegroundColor DarkGray
    Write-Host "  |   파이프라인 (순서대로)                   |" -ForegroundColor DarkGray
    Write-Host "  |  [1]  intake    새 파일 인식 / 등록       |" -ForegroundColor Green
    Write-Host "  |  [2]  prep      LLM 패킷 조립             |" -ForegroundColor Yellow
    Write-Host "  |  [3]  extract   LLM 처리 (분류/추출/노트) |" -ForegroundColor $extractColor
    Write-Host "  |  [4]  blogdraft 블로그 초안 생성          |" -ForegroundColor $(if ($s.ollama) { "Yellow" } else { "DarkGray" })
    Write-Host "  |  [L]  daily     하루 데일리 로그 정리      |" -ForegroundColor Green
    Write-Host "  |  [G]  register  새 초안 레지스트리 등록    |" -ForegroundColor Green
    Write-Host "  |  [V]  preview   초안 미리보기 대시보드     |" -ForegroundColor Cyan
    Write-Host "  |  [A]  approve   검수 → 05 승인 이동        |" -ForegroundColor Yellow
    Write-Host "  |  [5]  publish   승인본(05) → 발행         |" -ForegroundColor $(if ($s.ollama) { "Green" } else { "DarkGray" })
    Write-Host "  |  ---------------------------------------- |" -ForegroundColor DarkGray
    Write-Host "  |  [S]  현황 확인  처리 대기 목록 보기       |" -ForegroundColor Green
    Write-Host "  |  [R]  리뷰 검사  초안/발행글 품질 확인     |" -ForegroundColor Yellow
    Write-Host "  |  [D]  정리      차단 초안 .trash 이동      |" -ForegroundColor Yellow
    Write-Host "  |  [U]  내림      잘못 발행글 라이브 제거    |" -ForegroundColor Red
    Write-Host "  |  [X]  구조 보정  반복 섹션 dry-run         |" -ForegroundColor Yellow
    Write-Host "  |  [7]  전체 자동  생성→자동승인→미리보기   |" -ForegroundColor $(if ($s.ollama) { "Cyan" } else { "DarkGray" })
    Write-Host "  |                                          |" -ForegroundColor DarkGray
    Write-Host "  |  [Q]  종료                               |" -ForegroundColor DarkGray
    Write-Host "  |                                          |" -ForegroundColor DarkGray
    Write-Host "  +------------------------------------------+" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  키를 누르세요 >" -ForegroundColor White -NoNewline
}

function Run-Script {
    param([string]$ScriptName)
    $path = Join-Path $Root $ScriptName
    if (-not (Test-Path $path)) {
        Write-Host ""
        Write-Host ("  [ERROR] 스크립트 없음: {0}" -f $ScriptName) -ForegroundColor Red
        Start-Sleep -Seconds 2
        return
    }
    Write-Host ""
    Write-Host ("  >> {0} 실행 중..." -f $ScriptName) -ForegroundColor Cyan
    Write-Host ""
    & pwsh -ExecutionPolicy Bypass -File $path
    Write-Host ""
    Write-Host "  완료. 아무 키나 누르면 메뉴로 돌아갑니다..." -ForegroundColor DarkGray
    $null = [Console]::ReadKey($true)
}

function Run-Extract {
    # extract 전에 Ollama 상태 확인
    if (-not (Test-OllamaRunning)) {
        Write-Host ""
        Write-Host "  Ollama 서버가 꺼져 있습니다." -ForegroundColor Yellow
        Write-Host ("  [0] 을 눌러 먼저 Ollama 를 시작하거나,") -ForegroundColor Yellow
        Write-Host ("  Ollama 서버를 켠 뒤 다시 [3] 을 누르세요.") -ForegroundColor Yellow
        Write-Host ""
        Write-Host ("  ollama.exe: {0}" -f $OllamaExe) -ForegroundColor DarkGray
        Write-Host ""
        Write-Host "  아무 키나 누르면 메뉴로 돌아갑니다..." -ForegroundColor DarkGray
        $null = [Console]::ReadKey($true)
        return
    }
    Run-Script "run_learninglog_extract.ps1"
}

function Run-AllAuto {
    Write-Host ""
    Write-Host "  ============================================" -ForegroundColor Cyan
    Write-Host "   전체 자동 실행  [1 -> 2 -> 3 -> 4 -> A -> V]" -ForegroundColor Cyan
    Write-Host "   intake -> prep -> extract -> blogdraft -> approve -> preview" -ForegroundColor Cyan
    Write-Host "   => QA통과 신규는 자동 승인(05). 발행([5])만 수동." -ForegroundColor Cyan
    Write-Host "  ============================================" -ForegroundColor Cyan

    # Ollama 필수 확인
    if (-not (Test-OllamaRunning)) {
        Write-Host ""
        Write-Host "  [중단] Ollama 서버가 꺼져 있습니다." -ForegroundColor Red
        Write-Host "  [0] 으로 Ollama 를 먼저 시작한 후 [7] 을 다시 누르세요." -ForegroundColor Yellow
        Write-Host ""
        Write-Host "  아무 키나 누르면 메뉴로 돌아갑니다..." -ForegroundColor DarkGray
        $null = [Console]::ReadKey($true)
        return
    }

    Write-Host ""
    Write-Host "  LLM 처리 + 미리보기 생성까지 자동 진행됩니다 (발행은 제외)." -ForegroundColor Yellow
    Write-Host "  시작할까요? [Y] 시작 / 다른 키 취소" -ForegroundColor White -NoNewline
    $k = [Console]::ReadKey($true)
    if ($k.KeyChar.ToString().ToUpper() -ne "Y") {
        Write-Host ""
        Write-Host "  취소됨." -ForegroundColor DarkGray
        Start-Sleep -Seconds 1
        return
    }

    $steps = @(
        @{ name = "[1] intake    새 파일 등록";              script = "run_learninglog_intake.ps1" },
        @{ name = "[2] prep      LLM 패킷 조립";            script = "run_learninglog_prep.ps1" },
        @{ name = "[3] extract   LLM 처리 (분류/추출/노트)"; script = "run_learninglog_extract.ps1" },
        @{ name = "[4] blogdraft 블로그 초안 생성";          script = "run_learninglog_blogdraft.ps1" },
        @{ name = "[A] approve   QA통과 신규 자동 승인(05로)"; script = "run_learninglog_approve.ps1"; args = @("-All") },
        @{ name = "[V] preview   초안 미리보기 대시보드 생성"; script = "run_learninglog_preview.ps1" }
    )

    foreach ($step in $steps) {
        Write-Host ""
        Write-Host ("  ── {0} ──" -f $step.name) -ForegroundColor Cyan
        Write-Host ""
        $p = Join-Path $Root $step.script
        $stepArgs = @(); if ($step.ContainsKey('args')) { $stepArgs = $step.args }
        if (Test-Path $p) {
            & pwsh -ExecutionPolicy Bypass -File $p @stepArgs
            if ($LASTEXITCODE -ne 0) {
                Write-Host ""
                Write-Host ("  [중단] {0} 실패 (exit {1})" -f $step.script, $LASTEXITCODE) -ForegroundColor Red
                Write-Host "  위 오류를 먼저 고친 뒤 다시 실행하세요." -ForegroundColor Yellow
                Write-Host ""
                Write-Host "  아무 키나 누르면 메뉴로 돌아갑니다..." -ForegroundColor DarkGray
                $null = [Console]::ReadKey($true)
                return
            }
        } else {
            Write-Host ("  [SKIP] 스크립트 없음: {0}" -f $step.script) -ForegroundColor DarkGray
        }
    }

    Write-Host ""
    Write-Host "  ============================================" -ForegroundColor Green
    Write-Host "   *** 전체 자동 완료! ***" -ForegroundColor Green
    Write-Host "   QA통과 신규는 자동 승인됨(05). 미리보기 확인 후" -ForegroundColor Green
    Write-Host "   [5] publish 만 누르면 신규가 라이브에 올라갑니다." -ForegroundColor Green
    Write-Host "  ============================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "  아무 키나 누르면 메뉴로 돌아갑니다..." -ForegroundColor DarkGray
    $null = [Console]::ReadKey($true)
}

# ─────────────────────────────────────────────────────────
# 메뉴 루프
# ─────────────────────────────────────────────────────────
while ($true) {
    Show-Menu
    $key = [Console]::ReadKey($true)
    $ch  = $key.KeyChar.ToString().ToUpper()

    switch ($ch) {
        "0" { Start-OllamaServer }
        "1" { Run-Script "run_learninglog_intake.ps1" }
        "2" { Run-Script "run_learninglog_prep.ps1" }
        "3" { Run-Extract }
        "4" { Run-Script "run_learninglog_blogdraft.ps1" }
        "L" { Run-Script "run_learninglog_daily.ps1" }
        "G" { Run-Script "run_learninglog_register_drafts.ps1" }
        "V" { Run-Script "run_learninglog_preview.ps1" }
        "A" { Run-Script "run_learninglog_approve.ps1" }
        "5" { Run-Script "run_learninglog_publish.ps1" }
        "S" { Run-Script "run_learninglog_queue.ps1" }
        "R" { Run-Script "run_learninglog_review.ps1" }
        "D" { Run-Script "run_learninglog_cleanup.ps1" }
        "U" { Run-Script "run_learninglog_unpublish.ps1" }
        "X" { Run-Script "run_learninglog_restructure.ps1" }
        "7" { Run-AllAuto }
        "Q" {
            Write-Host ""
            Write-Host "  종료합니다." -ForegroundColor DarkGray
            Write-Host ""
            exit 0
        }
    }
}
