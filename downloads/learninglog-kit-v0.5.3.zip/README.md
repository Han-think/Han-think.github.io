# learninglog-kit 0.5.3

LearningLog is a personal learning pipeline that turns raw study material into reviewed notes and publishable blog drafts.

This kit contains two ways to use LearningLog:

- **Python package / web UI**: the original cross-platform kit under `src/learninglog`.
- **Windows local PowerShell runner**: the mature local workflow under `local_powershell/`.

Version 0.5.3 keeps the Python package intact and updates the Windows runner with the preview hotfixes from the local workflow.

---

## Which Version Should I Use?

Use the **Python package / web UI** if you want the lighter packaged tool:

```powershell
pip install "learninglog-kit[web,gemini]"
learninglog ui
```

Use the **Windows local PowerShell runner** if you want the full local workflow with preview, approval, publish, unpublish, daily posts, QA gates, and local Ollama support:

```powershell
cd local_powershell
.\LearningLog.bat
```

For the Windows runner, read `local_powershell/README.md` first. That document describes the current folder structure and menu flow.

---

## Windows Local Runner

The Windows runner is designed around this workspace shape:

```text
00_inbox
01_registry
02_extracted
03_working_notes
04_blog_drafts
05_ready_to_publish
06_published
07_archive
08_templates
09_reports
_local_core
```

The main flow is:

```text
intake -> prep -> extract -> blogdraft -> approve -> preview -> publish
```

The launcher also includes daily post generation, draft registration, review checks, cleanup, restructure dry-runs, and unpublish support.

### New in 0.5.3

- Fixes the preview dashboard when exactly one draft is visible.
- Keeps preview JSON stable as an array for zero, one, or many drafts.
- Adds a guard for one-item badge data in the preview UI.
- Daily combined posts show member source notes in the original-note pane instead of pointing back to the daily draft itself.
- Preview and approve exclude byproduct drafts by default.
- Daily combined posts use readable Korean section titles instead of internal slugs.
- Publish shows `new add` and `existing update` counts before copying to the blog source.
- Publish asks for confirmation when existing posts will be updated.
- Unpublish can target an already-published post by URL, slug, or listed item.
- The package excludes personal notes, generated drafts, published copies, reports, and internal operator documents.

---

## Python Package Quick Start

Install:

```bash
pip install learninglog-kit
```

Optional providers:

```bash
pip install "learninglog-kit[gemini]"
pip install "learninglog-kit[groq]"
pip install "learninglog-kit[all]"
```

Initialize a workspace:

```bash
mkdir my-learning
cd my-learning
learninglog init
```

Run the web UI:

```bash
pip install "learninglog-kit[web,gemini]"
learninglog ui
```

The original Python-oriented docs remain in `docs/`, especially:

- `docs/quickstart.md`
- `docs/llm-providers.md`
- `docs/gemini-api-setup.md`
- `docs/daily-workflow.md`

---

## Distribution Notes

This zip intentionally does **not** include private workspace data:

- no `00_inbox/` source files
- no registry rows from a personal workspace
- no extracted notes, working notes, drafts, ready-to-publish posts, published copies, reports, or trash
- no `AGENTS.md` or `_CONTROL/` internal operating documents
- no `.learninglog/config.yaml` secrets

The included files are a clean kit baseline plus the reusable local runner scripts and templates.
