# LearningLog Windows Local Runner

This folder contains the Windows PowerShell version of LearningLog. It is the full local workflow for turning raw study material into reviewed blog drafts and approved posts.

## Start

Run:

```powershell
.\LearningLog.bat
```

The batch file opens the PowerShell launcher:

```text
learninglog_launch.ps1
```

The launcher menu is the normal entry point. It checks the current pipeline status, Ollama availability, pending prep packets, draft counts, and published counts.

## Folder Structure

The runner expects this workspace layout:

```text
00_inbox              raw source files
01_registry           CSV registry and source tracking
02_extracted          extracted factual summaries
03_working_notes      personal learning notes
04_blog_drafts        Hugo-style blog drafts
05_ready_to_publish   approved posts waiting for publish
06_published          local copies after publish
07_archive            archived processed material
08_templates          Markdown and CSV templates
09_reports            generated reports, previews, prep packets
_local_core           shared PowerShell module and local assets
```

Do not put private data into this kit folder before redistributing it. The kit is meant to carry scripts, templates, and reusable local assets only.

## Main Flow

Use the menu in this order:

```text
[1] intake
[2] prep
[3] extract
[4] blogdraft
[A] approve
[V] preview
[5] publish
```

Short version:

- `intake` registers new source files.
- `prep` builds LLM prep packets.
- `extract` uses the configured local LLM flow to classify, extract, and create notes.
- `blogdraft` creates publishable blog drafts.
- `approve` moves QA-passing drafts into `05_ready_to_publish`.
- `preview` generates the local review dashboard.
- `publish` copies approved posts into the configured blog source and runs the publish flow.

## Daily Posts

Daily combined posts are generated from member notes. In this version, daily section titles are corrected before table-of-contents generation:

- internal slugs such as `am-01-join-groupby-having-churn` are not used as public section titles
- readable Korean titles are generated or derived
- the table of contents and body section headings match

## Preview And Approval

Preview and approval exclude byproduct drafts by default. This keeps partial notes, intermediate summaries, and generated side products out of the normal publish path.

Use explicit review when you want to inspect or recover excluded material.

## Publish Safety

Before publishing, the script checks the final destination path:

```text
blog-source/content/{section}/{filename}.md
```

It then shows:

```text
new add: N
existing update: M
```

If any existing post will be updated, publish asks for confirmation before copying, building, or pushing anything.

## Unpublish

The unpublish script can remove an already-published post by list selection, file name, slug, or published URL. It is intended for correcting accidental publishes without manually hunting through the blog content folder.

## Notes

- Keep `00_inbox` source files immutable.
- Copying into `blog-source/content` should happen only through the explicit publish step.
- Keep `.learninglog/config.yaml` and any API keys outside redistributable zips.
- This runner is Windows-first and expects PowerShell 7.
