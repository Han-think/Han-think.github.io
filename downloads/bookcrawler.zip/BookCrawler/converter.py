"""
BookCrawler · 변환기 (converter.py)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
역할: 스크레이퍼가 수집한 책 dict → Hugo .md 파일 생성

Hugo Front Matter 형식:
  +++
  title   = "..."
  date    = "2026-05-27T00:00:00+09:00"
  categories = ["books"]
  tags    = ["book-review", "fiction", ...]
  ...
  +++
"""

import logging
import re
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Dict

from config import (
    HUGO_CONTENT_DIR,
    HUGO_CATEGORY,
    HUGO_EXTRA_TAGS,
    RATING_EMOJI,
)

logger = logging.getLogger(__name__)

# KST = UTC+9
KST = timezone(timedelta(hours=9))


# ─── 유틸 ────────────────────────────────────────────────────────────────────

def _slugify(text: str) -> str:
    """제목을 URL-safe slug로 변환 (소문자, 공백→하이픈, 특수문자 제거)."""
    text = text.lower().strip()
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"[\s_]+", "-", text)
    text = re.sub(r"-+", "-", text)
    return text[:80]  # 너무 길면 자름


def _escape_toml(text: str) -> str:
    """TOML 문자열 안의 큰따옴표·백슬래시 이스케이프."""
    return text.replace("\\", "\\\\").replace('"', '\\"')


def _build_front_matter(book: Dict, pub_date: datetime) -> str:
    """TOML 형식의 Hugo Front Matter 문자열 반환."""
    title   = _escape_toml(book["title"])
    date_s  = pub_date.strftime("%Y-%m-%dT%H:%M:%S+09:00")
    rating  = book.get("rating", 0)
    emoji   = RATING_EMOJI.get(rating, "")
    category_raw = book.get("category", "Fiction")

    # 태그 구성: 기본 태그 + 장르 카테고리 + 별점 태그
    tags = list(HUGO_EXTRA_TAGS)  # 복사
    genre_slug = _slugify(category_raw)
    if genre_slug and genre_slug not in tags:
        tags.append(genre_slug)
    if rating:
        tags.append(f"rating-{rating}")

    tags_toml = ", ".join(f'"{t}"' for t in tags)
    cat_toml  = f'"{HUGO_CATEGORY}"'

    lines = [
        "+++",
        f'title      = "{title}"',
        f'date       = "{date_s}"',
        f'categories = [{cat_toml}]',
        f'tags       = [{tags_toml}]',
        f'draft      = false',
        f'cover      = "{book.get("cover_url", "")}"',
        f'upc        = "{book.get("upc", "")}"',
        f'price      = "{book.get("price", 0.0)}"',
        f'rating     = {rating}',
        f'rating_emoji = "{emoji}"',
        "+++",
    ]
    return "\n".join(lines)


def _build_body(book: Dict) -> str:
    """마크다운 본문 생성."""
    rating  = book.get("rating", 0)
    emoji   = RATING_EMOJI.get(rating, "")
    price   = book.get("price", 0.0)
    avail   = "재고 있음 ✅" if book.get("available") else "품절 ❌"
    desc    = book.get("description", "").strip() or "설명 없음"
    upc     = book.get("upc", "-")
    cover   = book.get("cover_url", "")
    category_raw = book.get("category", "Fiction")

    lines = []

    # 표지 이미지
    if cover:
        lines.append(f'![표지]({cover})\n')

    # 기본 정보 테이블
    lines += [
        "## 📖 기본 정보\n",
        "| 항목 | 내용 |",
        "|------|------|",
        f"| 장르 | {category_raw} |",
        f"| 가격 | £{price:.2f} |",
        f"| 별점 | {emoji} ({rating}/5) |",
        f"| 재고 | {avail} |",
        f"| UPC  | `{upc}` |",
        "",
    ]

    # 책 설명
    lines += [
        "## 📝 책 소개\n",
        desc,
        "",
    ]

    # 파이프라인 출처 안내
    lines += [
        "---",
        "",
        "> 이 포스트는 **BookCrawler** 자동 파이프라인으로 생성되었습니다.",
        "> 출처: [books.toscrape.com](http://books.toscrape.com)",
        "",
    ]

    return "\n".join(lines)


# ─── 공개 API ────────────────────────────────────────────────────────────────

def book_to_markdown(book: Dict, pub_date: datetime) -> str:
    """
    책 dict + 발행 일시 → Hugo 마크다운 전체 문자열.

    Args:
        book:     scraper.scrape_books_with_details()의 원소
        pub_date: KST 기준 발행 datetime

    Returns:
        Hugo .md 파일 내용 (front matter + 본문)
    """
    fm   = _build_front_matter(book, pub_date)
    body = _build_body(book)
    return fm + "\n\n" + body


def save_markdown(book: Dict, pub_date: datetime) -> Path:
    """
    마크다운을 HUGO_CONTENT_DIR 에 파일로 저장.

    파일명: {date}_{slug}.md
      예시: 2026-05-27_a-light-in-the-attic.md

    Returns:
        저장된 파일의 Path 객체
    """
    HUGO_CONTENT_DIR.mkdir(parents=True, exist_ok=True)

    date_prefix = pub_date.strftime("%Y-%m-%d")
    slug        = _slugify(book["title"])
    filename    = f"{date_prefix}_{slug}.md"
    filepath    = HUGO_CONTENT_DIR / filename

    content = book_to_markdown(book, pub_date)
    filepath.write_text(content, encoding="utf-8")

    logger.info(f"[변환 완료] {filepath.name}")
    return filepath
