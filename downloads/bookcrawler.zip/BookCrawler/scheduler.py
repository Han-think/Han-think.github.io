"""
BookCrawler · 스케줄러 (scheduler.py)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
역할:
  - queue_manager에서 책을 하나씩 꺼내 converter + publisher 실행
  - SCHEDULE_INTERVAL_MIN 간격으로 반복 (기본 5분)
  - POSTS_TO_UPLOAD 개 발행 완료 후 자동 종료

사용한 라이브러리:
  - schedule  (pip install schedule)
  - threading (표준 라이브러리, Ctrl-C 대응)

스케줄링 흐름:
  ┌─────────────────────────────────────────────────────┐
  │ 1. 큐에서 pop_next_book()                            │
  │ 2. converter.save_markdown() → .md 파일 생성         │
  │ 3. publisher.publish_post()  → Hugo build + git push │
  │ 4. queue_manager.mark_as_posted()                    │
  │ 5. 발행 횟수 == POSTS_TO_UPLOAD → schedule 종료      │
  └─────────────────────────────────────────────────────┘
"""

import logging
import time
from datetime import datetime, timezone, timedelta

import schedule

from config import (
    SCHEDULE_INTERVAL_MIN,
    POSTS_TO_UPLOAD,
)
from converter import save_markdown
from publisher import publish_post
from queue_manager import pop_next_book, mark_as_posted, queue_size, posted_count

logger = logging.getLogger(__name__)

KST = timezone(timedelta(hours=9))

# ─── 카운터 (모듈 레벨 — schedule 콜백에서 접근) ─────────────────────────────
_published_this_run: int = 0
_target: int = POSTS_TO_UPLOAD
_stop_flag: bool = False


def _upload_one() -> None:
    """스케줄이 호출하는 단위 작업: 책 1권 발행."""
    global _published_this_run, _stop_flag

    if _stop_flag:
        return

    # ── 남은 목표 확인
    remaining = _target - _published_this_run
    if remaining <= 0:
        logger.info("[스케줄] 목표 달성 → 종료 플래그 설정")
        _stop_flag = True
        return

    # ── 큐에서 꺼내기
    book = pop_next_book()
    if book is None:
        logger.warning("[스케줄] 큐가 비어 있음 — 이번 주기 건너뜀")
        return

    logger.info(
        f"[스케줄] 발행 시작 [{_published_this_run + 1}/{_target}] "
        f"'{book['title'][:50]}'"
    )

    # ── .md 파일 생성
    pub_date = datetime.now(tz=KST)
    try:
        md_path = save_markdown(book, pub_date)
    except Exception as e:
        logger.error(f"[스케줄] 변환 실패: {e}")
        return

    # ── Hugo 빌드 + git push
    ok = publish_post(book_title=book["title"])
    if not ok:
        logger.error(f"[스케줄] 발행 실패: '{book['title'][:40]}'")
        # 실패한 책은 re-queue하지 않음 (재시도 원하면 run.py --retry)
        return

    # ── 완료 기록
    mark_as_posted(book)
    _published_this_run += 1
    logger.info(
        f"[스케줄] ✅ 발행 완료 {_published_this_run}/{_target} "
        f"| 남은 큐: {queue_size()}권 | 누적 발행: {posted_count()}권"
    )

    # ── 목표 달성 시 종료 플래그
    if _published_this_run >= _target:
        logger.info("[스케줄] 목표 달성 → 종료 준비")
        _stop_flag = True


# ─── 공개 API ─────────────────────────────────────────────────────────────────

def run_scheduler(
    interval_min: int = SCHEDULE_INTERVAL_MIN,
    posts_to_upload: int = POSTS_TO_UPLOAD,
    run_immediately: bool = True,
) -> None:
    """
    스케줄러 메인 루프.

    Args:
        interval_min:    업로드 주기 (분)
        posts_to_upload: 이번 실행에서 발행할 최대 포스트 수
        run_immediately: True면 첫 번째 실행을 즉시 수행 (interval 대기 없이)
    """
    global _published_this_run, _target, _stop_flag

    _published_this_run = 0
    _target = posts_to_upload
    _stop_flag = False

    logger.info(
        f"[스케줄러 시작] 목표={_target}권 | 주기={interval_min}분 | "
        f"즉시 실행={run_immediately}"
    )

    # 스케줄 등록
    schedule.every(interval_min).minutes.do(_upload_one)

    # 첫 실행을 지금 바로 할지 여부
    if run_immediately:
        _upload_one()

    # 메인 루프
    while not _stop_flag:
        schedule.run_pending()
        time.sleep(10)  # 10초 간격으로 pending 체크

    schedule.clear()
    logger.info(
        f"[스케줄러 종료] 이번 실행 발행 수={_published_this_run} | "
        f"누적 발행={posted_count()}권"
    )
