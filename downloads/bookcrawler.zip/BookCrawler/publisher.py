"""
BookCrawler · 발행기 (publisher.py)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
역할:
  1. Hugo 빌드 실행 (hugo --minify)
  2. git add / commit / push (Windows subprocess)

전제:
  - C:\\Ollama-IPEX\\blog-source 가 git 저장소
  - 원격 origin이 GitHub Pages 저장소에 연결됨
  - git 및 hugo가 PATH 또는 설정된 경로에 존재
"""

import logging
import subprocess
from pathlib import Path
from typing import Optional

from config import (
    HUGO_SOURCE_ROOT,
    HUGO_EXE,
    GIT_COMMIT_AUTHOR,
    GIT_COMMIT_EMAIL,
)

logger = logging.getLogger(__name__)


# ─── 내부 헬퍼 ───────────────────────────────────────────────────────────────

def _run(cmd: list, cwd: Path, label: str) -> bool:
    """
    subprocess로 명령 실행.

    Returns:
        True  = 성공 (returncode 0)
        False = 실패
    """
    logger.info(f"[{label}] 실행: {' '.join(str(c) for c in cmd)}")
    try:
        result = subprocess.run(
            cmd,
            cwd=str(cwd),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        if result.stdout.strip():
            logger.debug(f"[{label}] stdout: {result.stdout.strip()}")
        if result.returncode != 0:
            logger.error(f"[{label}] 실패 (code {result.returncode}): {result.stderr.strip()}")
            return False
        logger.info(f"[{label}] 완료")
        return True
    except FileNotFoundError as e:
        logger.error(f"[{label}] 실행 파일 없음: {e}")
        return False
    except Exception as e:
        logger.error(f"[{label}] 예외: {e}")
        return False


# ─── Hugo 빌드 ───────────────────────────────────────────────────────────────

def hugo_build() -> bool:
    """
    Hugo 사이트 빌드.

    Returns:
        True = 빌드 성공
    """
    cmd = [HUGO_EXE, "--minify", "--logLevel", "warn"]
    return _run(cmd, cwd=HUGO_SOURCE_ROOT, label="HUGO BUILD")


# ─── Git 자동화 ──────────────────────────────────────────────────────────────

def _git_config_local() -> None:
    """로컬 저장소에 author 정보 설정 (글로벌 설정 덮어쓰기 방지)."""
    _run(
        ["git", "config", "user.name",  GIT_COMMIT_AUTHOR],
        cwd=HUGO_SOURCE_ROOT, label="GIT CONFIG name",
    )
    _run(
        ["git", "config", "user.email", GIT_COMMIT_EMAIL],
        cwd=HUGO_SOURCE_ROOT, label="GIT CONFIG email",
    )


def git_add_all() -> bool:
    """content/ 와 public/ 변경 사항을 스테이징."""
    return _run(
        ["git", "add", "content/", "public/"],
        cwd=HUGO_SOURCE_ROOT, label="GIT ADD",
    )


def git_commit(message: str) -> bool:
    """스테이지된 변경 사항을 커밋."""
    return _run(
        ["git", "commit", "-m", message],
        cwd=HUGO_SOURCE_ROOT, label="GIT COMMIT",
    )


def git_push(remote: str = "origin", branch: str = "main") -> bool:
    """원격 저장소에 푸시."""
    return _run(
        ["git", "push", remote, branch],
        cwd=HUGO_SOURCE_ROOT, label="GIT PUSH",
    )


# ─── 통합 발행 ───────────────────────────────────────────────────────────────

def publish_post(book_title: str, remote: str = "origin", branch: str = "main") -> bool:
    """
    Hugo 빌드 → git add → commit → push 원스톱 실행.

    Args:
        book_title: 커밋 메시지에 사용할 책 제목
        remote:     git remote 이름 (기본 'origin')
        branch:     푸시할 브랜치 (기본 'main')

    Returns:
        True = 전 단계 성공
    """
    _git_config_local()

    # 1. Hugo 빌드
    if not hugo_build():
        logger.error("[PUBLISH] Hugo 빌드 실패 → 중단")
        return False

    # 2. git add
    if not git_add_all():
        logger.error("[PUBLISH] git add 실패 → 중단")
        return False

    # 3. git commit (변경 없으면 스킵)
    commit_msg = f"📚 [BookCrawler] {book_title[:60]}"
    ok = git_commit(commit_msg)
    if not ok:
        # "nothing to commit" 도 returncode 1 → 경고만
        logger.warning("[PUBLISH] git commit 실패 또는 변경 없음")
        # push는 시도하지 않음
        return False

    # 4. git push
    if not git_push(remote, branch):
        logger.error("[PUBLISH] git push 실패")
        return False

    logger.info(f"[PUBLISH 완료] '{book_title[:40]}' → GitHub Pages")
    return True
