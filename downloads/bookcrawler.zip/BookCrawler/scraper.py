"""
BookCrawler · 스크레이퍼 (scraper.py)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
대상: http://books.toscrape.com
라이브러리: requests, BeautifulSoup4

흐름:
  1. 목록 페이지 (page-N.html) → 책 기본 정보 수집
  2. 개별 책 상세 페이지 → 설명·카테고리·UPC 수집
  3. 수집 결과를 dict 리스트로 반환
"""

import logging
import time
from typing import Dict, List, Optional

import requests
from bs4 import BeautifulSoup

from config import (
    REQUEST_DELAY_SEC,
    REQUEST_TIMEOUT,
    RATING_MAP,
    SCRAPE_BASE_URL,
    SCRAPE_PAGES,
)

# ─── 로거 설정 ────────────────────────────────────────────────────────────────
logger = logging.getLogger(__name__)


# ─── 공통 헬퍼 ───────────────────────────────────────────────────────────────

def _get_soup(url: str, session: requests.Session) -> Optional[BeautifulSoup]:
    """URL을 GET하고 BeautifulSoup을 반환. 실패 시 None."""
    try:
        resp = session.get(url, timeout=REQUEST_TIMEOUT)
        resp.raise_for_status()
        resp.encoding = "utf-8"
        return BeautifulSoup(resp.text, "html.parser")
    except requests.RequestException as e:
        logger.warning(f"[FETCH 실패] {url} → {e}")
        return None


def _rating_to_int(word: str) -> int:
    """'Three' → 3 변환"""
    return RATING_MAP.get(word, 0)


def _parse_price(price_str: str) -> float:
    """'£12.34' → 12.34"""
    cleaned = price_str.replace("£", "").replace("Â", "").strip()
    try:
        return float(cleaned)
    except ValueError:
        return 0.0


# ─── 목록 페이지 파싱 ─────────────────────────────────────────────────────────

def _parse_book_card(article: BeautifulSoup) -> Dict:
    """
    목록 페이지의 <article class="product_pod"> 하나를 파싱.

    수집 항목:
      - title      : 전체 제목
      - price      : float (파운드화)
      - rating     : int (1~5)
      - available  : bool
      - detail_url : 상세 페이지 URL (절대 경로)
      - cover_url  : 표지 이미지 URL
    """
    # 제목 (img alt 또는 h3 > a title)
    title_tag = article.select_one("h3 > a")
    title = title_tag["title"] if title_tag else "Unknown"

    # 가격
    price_tag = article.select_one("p.price_color")
    price = _parse_price(price_tag.text) if price_tag else 0.0

    # 별점 (class="star-rating Three")
    rating_tag = article.select_one("p.star-rating")
    rating_word = rating_tag["class"][1] if rating_tag else "Zero"
    rating = _rating_to_int(rating_word)

    # 재고
    avail_tag = article.select_one("p.availability")
    available = "In stock" in avail_tag.text if avail_tag else False

    # 상세 URL
    rel_url = title_tag["href"] if title_tag else ""
    # 목록 페이지의 상대 경로는 "../../.../foo.html" 형태
    rel_url = rel_url.replace("../", "")
    if not rel_url.startswith("catalogue/"):
        rel_url = "catalogue/" + rel_url
    detail_url = f"{SCRAPE_BASE_URL}/{rel_url}"

    # 표지 이미지
    img_tag = article.select_one("img.thumbnail")
    img_rel = img_tag["src"].replace("../", "") if img_tag else ""
    cover_url = f"{SCRAPE_BASE_URL}/{img_rel}"

    return {
        "title":      title,
        "price":      price,
        "rating":     rating,
        "available":  available,
        "detail_url": detail_url,
        "cover_url":  cover_url,
        # 상세 페이지에서 채울 필드
        "description": "",
        "category":    "Fiction",
        "upc":         "",
    }


def scrape_listing_pages(pages: int = SCRAPE_PAGES) -> List[Dict]:
    """
    books.toscrape.com의 페이지 1~N을 순회하며 책 카드를 수집.

    Args:
        pages: 크롤링할 페이지 수 (기본 config.SCRAPE_PAGES)

    Returns:
        책 dict 리스트 (detail_url 포함, 상세 정보 미수집 상태)
    """
    session = requests.Session()
    session.headers.update({
        "User-Agent": "BookCrawlerBot/1.0 (educational project)"
    })

    books: List[Dict] = []

    for page_num in range(1, pages + 1):
        url = f"{SCRAPE_BASE_URL}/catalogue/page-{page_num}.html"
        logger.info(f"[목록] 페이지 {page_num}/{pages} 크롤링 → {url}")

        soup = _get_soup(url, session)
        if soup is None:
            continue

        articles = soup.select("article.product_pod")
        logger.info(f"  → {len(articles)}권 발견")

        for article in articles:
            book = _parse_book_card(article)
            books.append(book)

        time.sleep(REQUEST_DELAY_SEC)   # 서버 부하 경감

    logger.info(f"[목록 완료] 총 {len(books)}권 수집")
    return books


# ─── 상세 페이지 파싱 ─────────────────────────────────────────────────────────

def scrape_book_detail(book: Dict, session: requests.Session) -> Dict:
    """
    책 상세 페이지를 크롤링해 description·category·upc를 채움.

    Args:
        book:    scrape_listing_pages()가 반환한 dict
        session: 재사용할 requests.Session

    Returns:
        상세 정보가 채워진 책 dict (in-place 수정 후 반환)
    """
    soup = _get_soup(book["detail_url"], session)
    if soup is None:
        return book

    # ── 카테고리 (breadcrumb: Home > Books > Mystery > Title)
    breadcrumbs = soup.select("ul.breadcrumb li")
    if len(breadcrumbs) >= 3:
        book["category"] = breadcrumbs[-2].get_text(strip=True)

    # ── 설명 (product description 섹션)
    desc_header = soup.find("div", id="product_description")
    if desc_header:
        desc_p = desc_header.find_next_sibling("p")
        book["description"] = desc_p.get_text(strip=True) if desc_p else ""

    # ── 상품 정보 테이블 (UPC 등)
    table = soup.select("table.table-striped tr")
    for row in table:
        header = row.find("th")
        value  = row.find("td")
        if header and value:
            key = header.get_text(strip=True)
            val = value.get_text(strip=True)
            if key == "UPC":
                book["upc"] = val

    return book


def scrape_books_with_details(
    pages: int = SCRAPE_PAGES,
    limit: Optional[int] = None,
) -> List[Dict]:
    """
    목록 크롤링 → 상위 `limit`권의 상세 페이지까지 크롤링.

    Args:
        pages: 목록 페이지 수
        limit: 상세 크롤링할 최대 책 수 (None = 전체)

    Returns:
        완전한 정보를 담은 책 dict 리스트
    """
    books = scrape_listing_pages(pages)

    if limit:
        books = books[:limit]

    session = requests.Session()
    session.headers.update({
        "User-Agent": "BookCrawlerBot/1.0 (educational project)"
    })

    total = len(books)
    for idx, book in enumerate(books, 1):
        logger.info(f"[상세] {idx}/{total} — {book['title'][:40]}")
        scrape_book_detail(book, session)
        time.sleep(REQUEST_DELAY_SEC)

    logger.info(f"[상세 완료] {total}권 상세 수집 완료")
    return books
