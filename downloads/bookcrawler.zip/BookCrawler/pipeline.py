"""
BookCrawler · 파이프라인 오케스트레이터 (pipeline.py)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
전체 파이프라인 제어:

  [PHASE 1] 스크레이핑
    books.toscrape.com → 5페이지 크롤링 → 상세 정보 수집
    → books.json 저장 → 큐 적재

  [PHASE 2] 스케줄 발행
    큐에서 5권 꺼내 5분 간격으로 Hugo .md 생성 + git push

  실행 모드 (run.py에서 선택):
    full      : PHASE1 + PHASE2 (기본)
    scrape    : PHASE1만 (수집 후 나중에 발행)
    publish   : PHASE2만 (기존 큐에서 발행)
    reset     : 큐 초기화
"""

import logging
from pathlib import Path
from typing import Optional

from config import (
    SCRAPE_PAGES,
    POSTS_TO_UPLOAD,
    SCHEDULE_INTERVAL_MIN,
    DATA_DIR,
    QUEUE_JSON,
    POSTED_JSON,
)
from scraper import scrape_books_with_details
from queue_manager import (
    ensure_data_dir,
    save_books,
    enqueue_books,
    queue_size,
    posted_count,
)
from scheduler import run_scheduler

logger = logging.getLogger(__name__)


# ─── PHASE 1 : 스크레이핑 ─────────────────────────────────────────────────────

def phase_scrape(
    pages: int = SCRAPE_PAGES,
    limit: Optional[int] = None,
) -> int:
    """
    크롤링 실행 → books.json 저장 → 큐 적재.

    Args:
        pages: 크롤링할 목록 페이지 수
        limit: 상세 수집 최대 권수 (None = 전체)

    Returns:
        큐에 새로 추가된 책 수
    """
    logger.info("=" * 60)
    logger.info("[PHASE 1] 스크레이핑 시작")
    logger.info(f"  대상 페이지: {pages}  |  상세 제한: {limit or '전체'}")
    logger.info("=" * 60)

    ensure_data_dir()

    books = scrape_books_with_details(pages=pages, limit=limit)
    if not books:
        logger.error("[PHASE 1] 수집된 책이 없습니다.")
        return 0

    save_books(books)
    added = enqueue_books(books)

    logger.info(f"[PHASE 1 완료] 수집 {len(books)}권 | 큐 추가 {added}권 | 현재 큐 {queue_size()}권")
    return added


# ─── PHASE 2 : 스케줄 발행 ────────────────────────────────────────────────────

def phase_publish(
    posts_to_upload: int = POSTS_TO_UPLOAD,
    interval_min: int = SCHEDULE_INTERVAL_MIN,
    run_immediately: bool = True,
) -> None:
    """
    스케줄러를 구동해 queue에서 posts_to_upload 개 발행.

    Args:
        posts_to_upload: 이번 실행에서 발행할 수
        interval_min:    발행 주기 (분)
        run_immediately: 첫 발행을 즉시 할지 여부
    """
    logger.info("=" * 60)
    logger.info("[PHASE 2] 스케줄 발행 시작")
    logger.info(f"  발행 목표: {posts_to_upload}권 | 주기: {interval_min}분")
    logger.info(f"  현재 큐: {queue_size()}권 | 누적 발행: {posted_count()}권")
    logger.info("=" * 60)

    if queue_size() == 0:
        logger.error("[PHASE 2] 큐가 비어 있음 — scrape 먼저 실행하세요.")
        return

    run_scheduler(
        interval_min=interval_min,
        posts_to_upload=posts_to_upload,
        run_immediately=run_immediately,
    )

    logger.info("[PHASE 2 완료]")


# ─── 파이프라인 모드 ──────────────────────────────────────────────────────────

def run_full(
    pages: int = SCRAPE_PAGES,
    posts_to_upload: int = POSTS_TO_UPLOAD,
    interval_min: int = SCHEDULE_INTERVAL_MIN,
) -> None:
    """PHASE1 스크레이핑 → PHASE2 스케줄 발행 전체 실행."""
    logger.info("▶▶ BookCrawler FULL PIPELINE 시작 ◀◀")
    added = phase_scrape(pages=pages)
    if added == 0:
        logger.error("스크레이핑 결과 없음 → 파이프라인 중단")
        return
    phase_publish(posts_to_upload=posts_to_upload, interval_min=interval_min)
    logger.info("▶▶ BookCrawler FULL PIPELINE 종료 ◀◀")


def run_scrape_only(pages: int = SCRAPE_PAGES) -> None:
    """PHASE1만 실행 (큐 적재까지)."""
    logger.info("▶▶ BookCrawler SCRAPE ONLY ◀◀")
    phase_scrape(pages=pages)


def run_publish_only(
    posts_to_upload: int = POSTS_TO_UPLOAD,
    interval_min: int = SCHEDULE_INTERVAL_MIN,
) -> None:
    """PHASE2만 실행 (기존 큐 이용)."""
    logger.info("▶▶ BookCrawler PUBLISH ONLY ◀◀")
    phase_publish(posts_to_upload=posts_to_upload, interval_min=interval_min)


def run_reset() -> None:
    """큐 및 완료 목록 초기화 (books.json은 유지)."""
    logger.warning("[RESET] queue.json / posted.json 삭제")
    for p in [QUEUE_JSON, POSTED_JSON]:
        if p.exists():
            p.unlink()
            logger.warning(f"  삭제: {p}")
    logger.warning("[RESET] 완료 — 다시 scrape 또는 full 실행 필요")
