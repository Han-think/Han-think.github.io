"""
BookCrawler · 큐 관리자 (queue_manager.py)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
역할:
  - 발행 대기 큐  (queue.json)   : 아직 발행 안 된 책 목록
  - 발행 완료 목록(posted.json) : 이미 발행된 책 UPC 집합
  - 원시 데이터   (books.json)  : 스크레이퍼 결과 전체

JSON 구조
  queue.json   → [ {book dict}, ... ]         # 발행 대기 순서
  posted.json  → { "upcs": ["abc123", ...] }  # 중복 방지 키
  books.json   → [ {book dict}, ... ]         # 전체 원시 데이터
"""

import json
import logging
from pathlib import Path
from typing import Dict, List, Optional, Set

from config import (
    DATA_DIR,
    BOOKS_JSON,
    QUEUE_JSON,
    POSTED_JSON,
)

logger = logging.getLogger(__name__)

# ─── 초기화 ──────────────────────────────────────────────────────────────────

def ensure_data_dir() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)


# ─── 범용 JSON I/O ───────────────────────────────────────────────────────────

def _read_json(path: Path, default):
    if not path.exists():
        return default
    try:
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        logger.warning(f"[JSON 읽기 실패] {path}: {e}")
        return default


def _write_json(path: Path, data) -> None:
    ensure_data_dir()
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


# ─── books.json ──────────────────────────────────────────────────────────────

def save_books(books: List[Dict]) -> None:
    """스크레이핑 결과 전체를 books.json에 저장."""
    _write_json(BOOKS_JSON, books)
    logger.info(f"[books.json] {len(books)}권 저장 → {BOOKS_JSON}")


def load_books() -> List[Dict]:
    return _read_json(BOOKS_JSON, [])


# ─── queue.json ──────────────────────────────────────────────────────────────

def save_queue(queue: List[Dict]) -> None:
    _write_json(QUEUE_JSON, queue)


def load_queue() -> List[Dict]:
    return _read_json(QUEUE_JSON, [])


def enqueue_books(books: List[Dict]) -> int:
    """
    발행 완료되지 않은 책만 큐에 추가 (중복 제거).

    Returns:
        새로 추가된 책 수
    """
    posted = load_posted_upcs()
    current_queue = load_queue()
    queued_upcs   = {b.get("upc", "") for b in current_queue}

    added = 0
    for book in books:
        upc = book.get("upc", "")
        if upc and (upc in posted or upc in queued_upcs):
            continue
        # UPC 없는 책은 제목으로 중복 체크
        if not upc:
            title = book.get("title", "")
            if any(b.get("title") == title for b in current_queue):
                continue

        current_queue.append(book)
        queued_upcs.add(upc)
        added += 1

    save_queue(current_queue)
    logger.info(f"[큐] {added}권 추가 → 대기 총 {len(current_queue)}권")
    return added


def pop_next_book() -> Optional[Dict]:
    """
    큐 맨 앞에서 책 하나를 꺼냄 (FIFO).

    Returns:
        책 dict 또는 None (큐가 비어 있을 때)
    """
    queue = load_queue()
    if not queue:
        return None
    book = queue.pop(0)
    save_queue(queue)
    logger.info(f"[큐] 꺼냄: '{book['title'][:40]}' | 남은 큐: {len(queue)}권")
    return book


def queue_size() -> int:
    return len(load_queue())


# ─── posted.json ─────────────────────────────────────────────────────────────

def load_posted_upcs() -> Set[str]:
    data = _read_json(POSTED_JSON, {"upcs": []})
    return set(data.get("upcs", []))


def mark_as_posted(book: Dict) -> None:
    """발행 완료 처리 — posted.json에 UPC 기록."""
    posted = load_posted_upcs()
    upc = book.get("upc", "")
    if upc:
        posted.add(upc)
    _write_json(POSTED_JSON, {"upcs": sorted(posted)})
    logger.info(f"[posted] 기록: UPC={upc or '(없음)'} / '{book['title'][:40]}'")


def posted_count() -> int:
    return len(load_posted_upcs())
