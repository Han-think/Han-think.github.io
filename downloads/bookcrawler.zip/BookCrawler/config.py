"""
BookCrawler · 설정 파일
모든 경로·URL·스케줄 설정을 한 곳에서 관리
"""

import os
from pathlib import Path

# ─────────────────────────────────────────
# 크롤링 대상
# ─────────────────────────────────────────
SCRAPE_BASE_URL   = "http://books.toscrape.com"
SCRAPE_PAGES      = 5          # 크롤링할 페이지 수
POSTS_TO_UPLOAD   = 5          # 업로드할 포스트 수
REQUEST_DELAY_SEC = 1.0        # 요청 사이 대기 (예의 바른 크롤링)
REQUEST_TIMEOUT   = 10         # 타임아웃 (초)

# ─────────────────────────────────────────
# 파일 경로
# ─────────────────────────────────────────
PROJECT_ROOT   = Path(__file__).parent
DATA_DIR       = PROJECT_ROOT / "data"
LOG_DIR        = PROJECT_ROOT / "logs"

BOOKS_JSON     = DATA_DIR / "books.json"       # 수집된 원시 데이터
QUEUE_JSON     = DATA_DIR / "queue.json"       # 발행 대기 큐
POSTED_JSON    = DATA_DIR / "posted.json"      # 발행 완료 목록

# ─────────────────────────────────────────
# Hugo 블로그 경로 (본인 환경에 맞게 수정)
# ─────────────────────────────────────────
HUGO_SOURCE_ROOT   = Path(r"C:\Ollama-IPEX\blog-source")
HUGO_CONTENT_DIR   = HUGO_SOURCE_ROOT / "content" / "posts" / "book-reviews"
HUGO_PUBLIC_DIR    = HUGO_SOURCE_ROOT / "public"
HUGO_EXE           = r"C:\Users\Lenovo\AppData\Local\Microsoft\WinGet\Links\hugo.exe"

# ─────────────────────────────────────────
# Git 설정
# ─────────────────────────────────────────
GIT_COMMIT_AUTHOR  = "BookCrawler Bot"
GIT_COMMIT_EMAIL   = "bot@bookcrawler.local"

# ─────────────────────────────────────────
# 스케줄 설정
# ─────────────────────────────────────────
SCHEDULE_INTERVAL_MIN = 5      # 5분에 1개 업로드

# ─────────────────────────────────────────
# Hugo Front Matter 기본값
# ─────────────────────────────────────────
HUGO_CATEGORY     = "dataset"   # 책 리뷰 → 데이터셋 카테고리에 포함
HUGO_EXTRA_TAGS   = ["book-review", "recipe", "reading"]

# 별점 → 이모지 변환
RATING_EMOJI = {1: "⭐", 2: "⭐⭐", 3: "⭐⭐⭐", 4: "⭐⭐⭐⭐", 5: "⭐⭐⭐⭐⭐"}
RATING_WORD  = {1: "One", 2: "Two", 3: "Three", 4: "Four", 5: "Five"}
RATING_MAP   = {"One": 1, "Two": 2, "Three": 3, "Four": 4, "Five": 5}
