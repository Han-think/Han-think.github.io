"""
BookCrawler · 진입점 (run.py)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
사용법:
  python run.py                        # 전체 실행 (스크레이핑 + 5분 간격 발행)
  python run.py --mode scrape          # 수집만
  python run.py --mode publish         # 발행만 (기존 큐 사용)
  python run.py --mode full            # 수집 + 발행
  python run.py --mode reset           # 큐 초기화
  python run.py --pages 3              # 크롤링 페이지 수 조정
  python run.py --posts 3              # 발행 수 조정
  python run.py --interval 2           # 발행 주기(분) 조정
  python run.py --no-immediate         # 첫 발행을 interval 후로 미룸
"""

import argparse
import logging
import sys
from pathlib import Path

# 로그 설정 (콘솔 + 파일)
from config import LOG_DIR, SCRAPE_PAGES, POSTS_TO_UPLOAD, SCHEDULE_INTERVAL_MIN

LOG_DIR.mkdir(parents=True, exist_ok=True)
LOG_FILE = LOG_DIR / "bookcrawler.log"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(LOG_FILE, encoding="utf-8"),
    ],
)

logger = logging.getLogger("run")


# ─── CLI ────────────────────────────────────────────────────────────────────

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="BookCrawler — books.toscrape.com → Hugo 블로그 자동 발행",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "--mode",
        choices=["full", "scrape", "publish", "reset"],
        default="full",
        help="실행 모드 (기본: full)",
    )
    parser.add_argument(
        "--pages",
        type=int,
        default=SCRAPE_PAGES,
        help=f"크롤링할 목록 페이지 수 (기본: {SCRAPE_PAGES})",
    )
    parser.add_argument(
        "--posts",
        type=int,
        default=POSTS_TO_UPLOAD,
        help=f"발행할 포스트 수 (기본: {POSTS_TO_UPLOAD})",
    )
    parser.add_argument(
        "--interval",
        type=int,
        default=SCHEDULE_INTERVAL_MIN,
        help=f"발행 주기 분 (기본: {SCHEDULE_INTERVAL_MIN}분)",
    )
    parser.add_argument(
        "--no-immediate",
        action="store_true",
        help="첫 발행을 interval 후로 미룸 (기본: 즉시 발행)",
    )
    return parser.parse_args()


# ─── 메인 ────────────────────────────────────────────────────────────────────

def main() -> None:
    args = parse_args()
    run_immediately = not args.no_immediate

    logger.info("=" * 60)
    logger.info("  BookCrawler 시작")
    logger.info(f"  모드      : {args.mode}")
    logger.info(f"  페이지    : {args.pages}")
    logger.info(f"  발행 수   : {args.posts}")
    logger.info(f"  주기(분)  : {args.interval}")
    logger.info(f"  즉시 실행 : {run_immediately}")
    logger.info("=" * 60)

    # 파이프라인 임포트는 로깅 설정 이후에
    from pipeline import run_full, run_scrape_only, run_publish_only, run_reset

    if args.mode == "full":
        run_full(
            pages=args.pages,
            posts_to_upload=args.posts,
            interval_min=args.interval,
        )
    elif args.mode == "scrape":
        run_scrape_only(pages=args.pages)
    elif args.mode == "publish":
        run_publish_only(
            posts_to_upload=args.posts,
            interval_min=args.interval,
        )
    elif args.mode == "reset":
        run_reset()
    else:
        logger.error(f"알 수 없는 모드: {args.mode}")
        sys.exit(1)

    logger.info("BookCrawler 종료")


if __name__ == "__main__":
    main()
